// src/ai/flows/predict-alert-relevance.ts
'use server';
/**
 * @fileOverview Predicts the relevance of flood alerts based on user location and sensor inputs.
 *
 * - predictAlertRelevance - A function that determines if a flood alert is relevant to a user.
 * - PredictAlertRelevanceInput - The input type for the predictAlertRelevance function.
 * - PredictAlertRelevanceOutput - The return type for the predictAlertRelevance function.
 */

import {ai} from '@/ai/genkit';
import {z} from 'genkit';

const PredictAlertRelevanceInputSchema = z.object({
  userLocation: z.object({
    latitude: z.number().describe('Latitude of the user.'),
    longitude: z.number().describe('Longitude of the user.'),
  }).describe('The current location of the user.'),
  floodZoneLocation: z.object({
    latitude: z.number().describe('Latitude of the flood zone.'),
    longitude: z.number().describe('Longitude of the flood zone.'),
  }).describe('The location of the flood zone.'),
  waterLevel: z.number().describe('Current water level at the flood zone in cm.'),
  alertThreshold: z.number().describe('Water level threshold for triggering an alert in cm.'),
  weatherCondition: z.string().describe('Current weather condition at the flood zone (e.g., sunny, rainy).'),
});
export type PredictAlertRelevanceInput = z.infer<typeof PredictAlertRelevanceInputSchema>;

const PredictAlertRelevanceOutputSchema = z.object({
  isRelevant: z.boolean().describe('Whether the alert is relevant to the user based on their location and the sensor inputs.'),
  reason: z.string().describe('The reason why the alert is relevant or not.'),
});
export type PredictAlertRelevanceOutput = z.infer<typeof PredictAlertRelevanceOutputSchema>;

export async function predictAlertRelevance(input: PredictAlertRelevanceInput): Promise<PredictAlertRelevanceOutput> {
  return predictAlertRelevanceFlow(input);
}

const prompt = ai.definePrompt({
  name: 'predictAlertRelevancePrompt',
  input: {schema: PredictAlertRelevanceInputSchema},
  output: {schema: PredictAlertRelevanceOutputSchema},
  prompt: `You are an AI assistant that determines the relevance of a flood alert for a user.

  Consider the user's location, the location of the flood zone, the current water level, the alert threshold, and the weather condition.

  User Location: Latitude: {{{userLocation.latitude}}}, Longitude: {{{userLocation.longitude}}}
  Flood Zone Location: Latitude: {{{floodZoneLocation.latitude}}}, Longitude: {{{floodZoneLocation.longitude}}}
  Water Level: {{{waterLevel}}} cm
  Alert Threshold: {{{alertThreshold}}} cm
  Weather Condition: {{{weatherCondition}}}

  Determine if the alert is relevant to the user, taking into account proximity, severity (water level compared to threshold), and weather conditions.
  Provide a clear reason for your determination.
  Return a JSON object.
  `,
});

const predictAlertRelevanceFlow = ai.defineFlow(
  {
    name: 'predictAlertRelevanceFlow',
    inputSchema: PredictAlertRelevanceInputSchema,
    outputSchema: PredictAlertRelevanceOutputSchema,
  },
  async input => {
    const {output} = await prompt(input);
    return output!;
  }
);
