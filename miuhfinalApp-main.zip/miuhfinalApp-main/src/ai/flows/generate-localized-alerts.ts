'use server';

/**
 * @fileOverview This file defines a Genkit flow for generating localized flood alerts for users.
 *
 * The flow takes a user's location and current water level readings as input,
 * determines the potential flood risk in the user's area, and generates a localized alert message.
 *
 * @interface GenerateLocalizedAlertsInput - The input type for the generateLocalizedAlerts function.
 * @interface GenerateLocalizedAlertsOutput - The output type for the generateLocalizedAlerts function.
 * @function generateLocalizedAlerts - The main function that triggers the localized alert generation flow.
 */

import {ai} from '@/ai/genkit';
import {z} from 'genkit';

const GenerateLocalizedAlertsInputSchema = z.object({
  latitude: z.number().describe('The latitude of the user.'),
  longitude: z.number().describe('The longitude of the user.'),
  waterLevel: z.number().describe('The current water level reading in cm.'),
  locationName: z.string().describe('The name of the location the water level reading is associated with (e.g. "Chilca River")'),
  alertThreshold: z.number().describe('The water level threshold (in cm) above which an alert should be generated.'),
});
export type GenerateLocalizedAlertsInput = z.infer<
  typeof GenerateLocalizedAlertsInputSchema
>;

const GenerateLocalizedAlertsOutputSchema = z.object({
  alertMessage: z.string().describe('A localized alert message for the user.'),
  alertLevel: z.enum(['Normal', 'Alerta', 'Crítica']).describe('The alert level based on the water level.'),
});
export type GenerateLocalizedAlertsOutput = z.infer<
  typeof GenerateLocalizedAlertsOutputSchema
>;

export async function generateLocalizedAlerts(
  input: GenerateLocalizedAlertsInput
): Promise<GenerateLocalizedAlertsOutput> {
  return generateLocalizedAlertsFlow(input);
}

const generateLocalizedAlertsPrompt = ai.definePrompt({
  name: 'generateLocalizedAlertsPrompt',
  input: {schema: GenerateLocalizedAlertsInputSchema},
  output: {schema: GenerateLocalizedAlertsOutputSchema},
  prompt: `You are an AI assistant that generates localized flood alerts for users based on their location and current water level readings.

  Based on the user's location (latitude: {{{latitude}}}, longitude: {{{longitude}}}) and the current water level reading from the {{{locationName}}} ({{{waterLevel}}} cm), determine the potential flood risk in the user's area.

  The alert threshold is {{{alertThreshold}}} cm. If the water level exceeds this threshold, generate an appropriate alert message and set the alert level accordingly.

  Consider the following alert levels:
  - Normal: Water level is below the alert threshold.
  - Alerta: Water level is approaching or slightly exceeding the alert threshold.
  - Crítica: Water level is significantly exceeding the alert threshold, indicating a high risk of flooding.

  Generate a concise and informative alert message that includes the location name, current water level, and the potential risk to the user.
  Also generate the alertLevel based on the same data.

  Example:
  Input: {latitude: -12.0681, longitude: -75.2100, waterLevel: 130, locationName: "Chilca River", alertThreshold: 120}
  Output: {alertMessage: "Alerta: El nivel del Río Chilca ha alcanzado los 130 cm, superando el umbral de alerta.  Se recomienda precaución en las zonas cercanas al río.", alertLevel: "Alerta"}
  `,
});

const generateLocalizedAlertsFlow = ai.defineFlow(
  {
    name: 'generateLocalizedAlertsFlow',
    inputSchema: GenerateLocalizedAlertsInputSchema,
    outputSchema: GenerateLocalizedAlertsOutputSchema,
  },
  async input => {
    const {output} = await generateLocalizedAlertsPrompt(input);
    return output!;
  }
);
