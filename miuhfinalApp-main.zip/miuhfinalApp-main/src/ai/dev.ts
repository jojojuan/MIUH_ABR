import { config } from 'dotenv';
config();

import '@/ai/flows/generate-localized-alerts.ts';
import '@/ai/flows/predict-alert-relevance.ts';