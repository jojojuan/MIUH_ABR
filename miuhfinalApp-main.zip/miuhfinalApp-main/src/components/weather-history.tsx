
'use client';

import { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Button } from '@/components/ui/button';
import { Download, FileDown, Loader2, Database } from 'lucide-react';
import { ScrollArea } from '@/components/ui/scroll-area';
import { format } from 'date-fns';
import jsPDF from 'jspdf';
import 'jspdf-autotable';
import * as XLSX from 'xlsx';
import { useToast } from '@/hooks/use-toast';

// Define el tipo para un reporte de clima que viene de tu backend MySQL
interface WeatherReport {
  id: number;
  locationName: string;
  temperature: string; // En MySQL DECIMAL se puede recibir como string
  humidity: string;
  precipitation: string;
  wind: string;
  timestamp: string; // En MySQL DATETIME se recibe como string
}

export default function WeatherHistory() {
  const { toast } = useToast();
  const [reports, setReports] = useState<WeatherReport[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    async function fetchWeatherHistory() {
      setIsLoading(true);
      setError(null);
      const token = localStorage.getItem('authToken');
      if (!token) {
        setError('Necesitas iniciar sesión para ver el historial.');
        setIsLoading(false);
        return;
      }

      try {
        const backendUrl = process.env.NEXT_PUBLIC_BACKEND_URL || 'http://localhost:3001';
        const response = await fetch(`${backendUrl}/api/weather-reports`, {
          headers: {
            'Authorization': `Bearer ${token}`,
          },
        });

        const data = await response.json();

        if (!response.ok) {
          throw new Error(data.message || 'No se pudo cargar el historial.');
        }

        setReports(data);
      } catch (err: any) {
        setError(err.message);
      } finally {
        setIsLoading(false);
      }
    }

    fetchWeatherHistory();
  }, []);

  const downloadPDF = () => {
    if (!reports) return;
    const doc = new jsPDF();
    doc.text("Historial de Reportes del Clima", 20, 10);
    (doc as any).autoTable({
      head: [['Fecha', 'Ubicación', 'Temp (°C)', 'Humedad (%)', 'Precip. (mm)', 'Viento (km/h)']],
      body: reports.map(report => [
        report.timestamp ? format(new Date(report.timestamp), 'dd/MM/yyyy HH:mm') : 'N/A',
        report.locationName,
        report.temperature,
        report.humidity,
        report.precipitation,
        report.wind,
      ]),
    });
    doc.save('historial_clima.pdf');
  };

  const downloadExcel = () => {
    if (!reports) return;
    const worksheet = XLSX.utils.json_to_sheet(
      reports.map(report => ({
        'Fecha': report.timestamp ? format(new Date(report.timestamp), 'dd/MM/yyyy HH:mm') : 'N/A',
        'Ubicación': report.locationName,
        'Temperatura (°C)': report.temperature,
        'Humedad (%)': report.humidity,
        'Precipitación (mm)': report.precipitation,
        'Viento (km/h)': report.wind,
      }))
    );
    const workbook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(workbook, worksheet, 'HistorialClima');
    XLSX.writeFile(workbook, 'historial_clima.xlsx');
  };
  
  const handleExportSql = () => {
    toast({
      title: "Función no implementada",
      description: "La exportación a SQL requiere un servicio de backend seguro.",
    });
  };

  return (
    <Card>
      <CardHeader>
        <div className="flex justify-between items-center">
          <CardTitle>Historial de Datos Guardados</CardTitle>
          <div className="flex flex-wrap gap-2">
            <Button variant="outline" size="sm" onClick={downloadPDF} disabled={!reports || reports.length === 0}>
              <FileDown className="mr-2 h-4 w-4" /> PDF
            </Button>
            <Button variant="outline" size="sm" onClick={downloadExcel} disabled={!reports || reports.length === 0}>
              <Download className="mr-2 h-4 w-4" /> Excel
            </Button>
             <Button variant="outline" size="sm" onClick={handleExportSql}>
              <Database className="mr-2 h-4 w-4" /> SQL
            </Button>
          </div>
        </div>
      </CardHeader>
      <CardContent>
        <ScrollArea className="h-64">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Fecha</TableHead>
                <TableHead>Ubicación</TableHead>
                <TableHead className="text-right">Temp.</TableHead>
                <TableHead className="text-right">Humedad</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {isLoading && (
                <TableRow>
                  <TableCell colSpan={4} className="text-center">
                    <div className="flex justify-center items-center">
                      <Loader2 className="mr-2 h-4 w-4 animate-spin" /> Cargando...
                    </div>
                  </TableCell>
                </TableRow>
              )}
              {error && (
                 <TableRow>
                  <TableCell colSpan={4} className="text-center text-destructive">
                    {error}
                  </TableCell>
                </TableRow>
              )}
              {!isLoading && !error && reports?.length === 0 && (
                 <TableRow>
                  <TableCell colSpan={4} className="text-center text-muted-foreground">
                    No hay datos guardados todavía.
                  </TableCell>
                </TableRow>
              )}
              {reports && reports.map((report) => (
                <TableRow key={report.id}>
                  <TableCell className="font-medium">
                    {report.timestamp ? format(new Date(report.timestamp), 'dd/MM/yyyy HH:mm') : 'N/A'}
                  </TableCell>
                  <TableCell>{report.locationName}</TableCell>
                  <TableCell className="text-right">{parseFloat(report.temperature).toFixed(1)}°C</TableCell>
                  <TableCell className="text-right">{parseFloat(report.humidity).toFixed(0)}%</TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </ScrollArea>
      </CardContent>
    </Card>
  );
}
