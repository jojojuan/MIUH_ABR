
'use client';

import Image from 'next/image';
import { Button } from '@/components/ui/button';
import { PlaceHolderImages } from '@/lib/placeholder-images';
import { ArrowRight } from 'lucide-react';

interface WelcomeScreenProps {
  onNext: () => void;
}

export default function WelcomeScreen({ onNext }: WelcomeScreenProps) {
  const welcomeImage = PlaceHolderImages.find(
    (img) => img.id === 'welcome-flood-image'
  );

  return (
    <div className="relative h-screen w-full flex flex-col justify-end">
      {welcomeImage && (
        <Image
          src={welcomeImage.imageUrl}
          alt={welcomeImage.description}
          layout="fill"
          objectFit="cover"
          className="z-0"
          data-ai-hint={welcomeImage.imageHint}
        />
      )}
      <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/50 to-transparent z-10" />
      <div className="relative z-20 p-8 text-white text-center">
        <h1 className="text-4xl font-bold mb-4 leading-tight">
          Juntos por un Huancayo más seguro
        </h1>
        <p className="text-lg text-white/90 mb-8">
          Tu participación es clave para prevenir y mitigar los riesgos de inundaciones.
        </p>
        <Button
          size="lg"
          onClick={onNext}
          className="w-full max-w-xs mx-auto py-6 text-lg font-semibold rounded-full bg-primary text-primary-foreground hover:bg-primary/90 shadow-lg"
        >
          Siguiente <ArrowRight className="ml-2 h-5 w-5" />
        </Button>
      </div>
    </div>
  );
}
