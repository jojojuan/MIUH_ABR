"use client";

import { cn } from "@/lib/utils";
import type { View } from "@/lib/types";
import { navItems } from "@/lib/data";

interface BottomNavProps {
  activeView: View;
  setActiveView: (view: View) => void;
}

export default function BottomNav({ activeView, setActiveView }: BottomNavProps) {
  return (
    <nav className="flex-shrink-0 bg-card border-t shadow-[0_-2px_10px_rgba(0,0,0,0.05)]">
      <div className="flex justify-around items-center h-20">
        {navItems.map(({ id, label, Icon }) => (
          <button
            key={id}
            onClick={() => setActiveView(id)}
            className={cn(
              "flex flex-col items-center gap-1 text-muted-foreground hover:text-primary transition-colors",
              { "text-primary": activeView === id }
            )}
          >
            <Icon className="h-6 w-6" />
            <span className="text-xs font-medium">{label}</span>
          </button>
        ))}
      </div>
    </nav>
  );
}
