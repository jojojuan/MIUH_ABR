"use client";

import MapComponent from '@/components/map-component';
import { meteoStations } from '@/lib/data';

interface StationsViewProps {
  isActive: boolean;
}

export default function StationsView({ isActive }: StationsViewProps) {
  return (
    <div className="h-full w-full">
        <MapComponent 
            sensors={meteoStations} 
            isActive={isActive} 
            center={[-11.6, -75.5]} // Center of Junin Region
            zoom={9}
        />
    </div>
  );
}
