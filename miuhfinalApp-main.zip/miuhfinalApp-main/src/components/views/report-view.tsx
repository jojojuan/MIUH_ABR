"use client";

import { useState, useEffect, useRef } from "react";
import { Camera, MapPin, Loader2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { submitReport } from "@/lib/actions";
import { incidentTypes } from "@/lib/data";
import type { View } from "@/lib/types";
import { AlertDialog, AlertDialogContent, AlertDialogHeader, AlertDialogTitle, AlertDialogDescription, AlertDialogFooter, AlertDialogAction } from "@/components/ui/alert-dialog";
import Image from "next/image";

interface ReportViewProps {
  setActiveView: (view: View) => void;
}

export default function ReportView({ setActiveView }: ReportViewProps) {
  const [location, setLocation] = useState("Detectando ubicación...");
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [showSuccessDialog, setShowSuccessDialog] = useState(false);
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [preview, setPreview] = useState<string | null>(null);
  const formRef = useRef<HTMLFormElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    const timer = setTimeout(() => {
      setLocation("Jr. Atahualpa 123, Chilca (±5m)");
    }, 1000);
    return () => clearTimeout(timer);
  }, []);
  
  useEffect(() => {
    if (!selectedFile) {
        setPreview(null)
        return
    }

    const objectUrl = URL.createObjectURL(selectedFile)
    setPreview(objectUrl)

    // free memory when ever this component is unmounted
    return () => URL.revokeObjectURL(objectUrl)
  }, [selectedFile])

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (!e.target.files || e.target.files.length === 0) {
        setSelectedFile(null)
        return
    }
    setSelectedFile(e.target.files[0])
  }


  const handleSubmit = async (event: React.FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    setIsSubmitting(true);
    const formData = new FormData(event.currentTarget);
    const result = await submitReport(formData);

    setIsSubmitting(false);

    if (result.success) {
      setShowSuccessDialog(true);
    } else {
      // Handle error, maybe with a toast
      console.error(result.message);
    }
  };

  const handleDialogClose = () => {
    setShowSuccessDialog(false);
    formRef.current?.reset();
    setSelectedFile(null);
    setActiveView("home");
  }

  return (
    <>
      <div className="p-4 bg-background">
        <h2 className="text-2xl font-bold mb-4">Nuevo Reporte</h2>
        <Card>
          <CardContent className="p-6">
            <form ref={formRef} onSubmit={handleSubmit} className="space-y-6">
              <div>
                <Label htmlFor="location" className="text-sm font-bold text-muted-foreground">UBICACIÓN</Label>
                <div className="relative mt-1">
                  <MapPin className="absolute left-3 top-1/2 -translate-y-1/2 h-5 w-5 text-destructive" />
                  <Input id="location" name="location" value={location} readOnly className="pl-10 bg-secondary" />
                </div>
              </div>

              <div>
                <Label htmlFor="incidentType" className="text-sm font-bold text-muted-foreground">TIPO DE INCIDENTE</Label>
                <Select name="incidentType" defaultValue={incidentTypes[0]} required>
                  <SelectTrigger id="incidentType" className="mt-1">
                    <SelectValue placeholder="Seleccione un tipo" />
                  </SelectTrigger>
                  <SelectContent>
                    {incidentTypes.map((type) => (
                      <SelectItem key={type} value={type}>{type}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div>
                <Label htmlFor="description" className="text-sm font-bold text-muted-foreground">DESCRIPCIÓN</Label>
                <Textarea
                  id="description"
                  name="description"
                  placeholder="Describe brevemente lo que estás reportando..."
                  className="mt-1"
                />
              </div>

              <div>
                <Label className="text-sm font-bold text-muted-foreground">EVIDENCIA FOTOGRÁFICA</Label>
                <div 
                  className="mt-1 flex justify-center items-center flex-col p-6 border-2 border-dashed rounded-lg cursor-pointer hover:bg-secondary transition-colors"
                  onClick={() => fileInputRef.current?.click()}
                >
                  {preview ? (
                     <div className="relative w-full h-40">
                        <Image src={preview} alt="Vista previa" layout="fill" objectFit="cover" className="rounded-md" />
                     </div>
                  ) : (
                    <>
                      <Camera className="h-10 w-10 text-muted-foreground mb-2" />
                      <p className="text-sm text-muted-foreground">Toca para tomar foto o subir</p>
                    </>
                  )}
                </div>
                <Input ref={fileInputRef} type="file" name="evidence" accept="image/*" className="hidden" onChange={handleFileChange} />
              </div>

              <Button type="submit" disabled={isSubmitting} className="w-full py-6 rounded-full font-bold text-base bg-destructive hover:bg-destructive/90">
                {isSubmitting ? (
                  <>
                    <Loader2 className="mr-2 h-5 w-5 animate-spin" />
                    Enviando...
                  </>
                ) : (
                  "ENVIAR REPORTE"
                )}
              </Button>
            </form>
          </CardContent>
        </Card>
      </div>

      <AlertDialog open={showSuccessDialog} onOpenChange={setShowSuccessDialog}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>¡Reporte Enviado!</AlertDialogTitle>
            <AlertDialogDescription>
              Gracias por tu colaboración. Las autoridades han sido notificadas y revisarán la situación.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogAction onClick={handleDialogClose}>Entendido</AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </>
  );
}
