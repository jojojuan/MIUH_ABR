"use client";

import { ArrowDown, Info } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import {
  ChartContainer,
  ChartTooltip,
  ChartTooltipContent,
} from "@/components/ui/chart";
import { waterLevelData, recentEvents } from "@/lib/data";
import {
  Area,
  AreaChart,
  CartesianGrid,
  XAxis,
  YAxis,
  ResponsiveContainer,
  Tooltip,
} from "recharts";
import type { SensorStatus } from "@/lib/types";

const chartConfig = {
  level: {
    label: "Nivel (cm)",
    color: "hsl(var(--primary))",
  },
};

const alertLevels: { level: SensorStatus; bg: string, text: string }[] = [
    { level: "Normal", bg: "bg-green-500", text: "text-white" },
    { level: "Alerta", bg: "bg-yellow-400", text: "text-slate-900" },
    { level: "Crítica", bg: "bg-red-500", text: "text-white" }
];

const currentStatus: SensorStatus = "Normal";

export default function MonitoringView() {
  const currentLevel = waterLevelData[waterLevelData.length - 1]?.level || 0;

  return (
    <div className="p-4 space-y-4 bg-background">
      <h2 className="text-2xl font-bold">Monitoreo Río Chilca</h2>
      
      <Card>
        <CardHeader>
          <div className="flex justify-between items-end mb-2">
            <div>
              <p className="text-sm text-muted-foreground">Nivel Actual</p>
              <h3 className="text-4xl font-bold text-primary">{currentLevel} cm</h3>
            </div>
            <div className="text-green-600 font-bold text-sm flex items-center">
              <ArrowDown className="h-4 w-4 mr-1" /> Bajando
            </div>
          </div>
        </CardHeader>
        <CardContent>
          <ChartContainer config={chartConfig} className="h-48 w-full">
            <AreaChart data={waterLevelData} margin={{ top: 5, right: 20, left: -10, bottom: 0 }}>
              <defs>
                <linearGradient id="colorLevel" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="hsl(var(--primary))" stopOpacity={0.8}/>
                  <stop offset="95%" stopColor="hsl(var(--primary))" stopOpacity={0.1}/>
                </linearGradient>
              </defs>
              <CartesianGrid vertical={false} strokeDasharray="3 3" />
              <XAxis dataKey="time" tick={{ fill: 'hsl(var(--muted-foreground))', fontSize: 12 }} axisLine={false} tickLine={false} />
              <YAxis tick={{ fill: 'hsl(var(--muted-foreground))', fontSize: 12 }} axisLine={false} tickLine={false} />
              <Tooltip 
                content={<ChartTooltipContent indicator="dot" />} 
                cursor={{stroke: 'hsl(var(--primary))', strokeWidth: 1, strokeDasharray: "3 3"}}
              />
              <Area type="monotone" dataKey="level" stroke="hsl(var(--primary))" strokeWidth={2} fillOpacity={1} fill="url(#colorLevel)" />
            </AreaChart>
          </ChartContainer>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Nivel de Alerta</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex gap-2">
            {alertLevels.map(({ level, bg, text }) => (
                <Badge 
                    key={level}
                    className={`w-full justify-center p-3 text-sm font-bold transition-all duration-300 ${bg} ${text} ${currentStatus === level ? 'opacity-100 scale-105 shadow-md' : 'opacity-40'}`}
                >
                    {level}
                </Badge>
            ))}
          </div>
          <p className="mt-3 text-sm text-muted-foreground flex items-center">
            <Info className="h-4 w-4 mr-1.5" />
            Última actualización: Hace 5 min
          </p>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Eventos Recientes</CardTitle>
        </CardHeader>
        <CardContent>
          <ul className="space-y-4">
            {recentEvents.map((event, index) => (
              <li key={index} className="flex items-center gap-4">
                <div className="bg-secondary p-3 rounded-lg">
                  <event.Icon className={`h-6 w-6 ${event.iconColor}`} />
                </div>
                <div>
                  <p className="font-semibold">{event.title}</p>
                  <p className="text-sm text-muted-foreground">{event.location}</p>
                </div>
              </li>
            ))}
          </ul>
        </CardContent>
      </Card>
    </div>
  );
}
