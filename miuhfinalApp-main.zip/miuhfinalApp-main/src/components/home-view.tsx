
"use client";

import { useState, useEffect } from 'react';
import MapComponent from '@/components/map-component';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { LineChart, Thermometer, Wind, Droplet, CloudRain, Loader2, Save } from 'lucide-react';
import type { View, Sensor } from '@/lib/types';
import { sensors } from '@/lib/data';
import { getRealWeather } from '@/lib/actions';
import { saveWeatherData } from '@/lib/weather-service';
import { Skeleton } from '../ui/skeleton';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { useToast } from '@/hooks/use-toast';
import WeatherHistory from '@/components/weather-history';

interface HomeViewProps {
  setActiveView: (view: View) => void;
  isActive: boolean;
}

type WeatherData = {
  temperature: number;
  humidity: number;
  precipitation: number;
  wind: number;
};

export default function HomeView({ setActiveView, isActive }: HomeViewProps) {
  const [selectedSensor, setSelectedSensor] = useState<Sensor>(sensors[0]);
  const [weather, setWeather] = useState<WeatherData | null>(null);
  const [loadingWeather, setLoadingWeather] = useState(true);
  const [isSaving, setIsSaving] = useState(false);
  const { toast } = useToast();

  useEffect(() => {
    async function fetchWeather() {
      if (!selectedSensor) return;
      setLoadingWeather(true);
      const result = await getRealWeather(selectedSensor.position[0], selectedSensor.position[1]);
      if (result.success) {
        setWeather(result.data);
      } else {
        setWeather(null); // Clear weather on error
      }
      setLoadingWeather(false);
    }
    fetchWeather();
  }, [selectedSensor]);

  const handleSensorChange = (sensorId: string) => {
    const sensor = sensors.find(s => s.id === sensorId);
    if (sensor) {
      setSelectedSensor(sensor);
    }
  };
  
  const handleSaveWeather = async () => {
    if (!weather) {
      toast({
        variant: "destructive",
        title: "Error",
        description: "No hay datos del clima para guardar.",
      });
      return;
    }

    setIsSaving(true);
    try {
      await saveWeatherData({ ...weather, locationName: selectedSensor.name });
      toast({
        title: "Datos Guardados",
        description: "Los datos del clima se han guardado correctamente en tu base de datos.",
      });
    } catch (error: any) {
      toast({
        variant: "destructive",
        title: "Error al guardar",
        description: error.message || "No se pudieron guardar los datos.",
      });
    } finally {
      setIsSaving(false);
    }
  };


  return (
    <div className="h-full w-full flex flex-col">
      <div className="relative flex-shrink-0 z-0" style={{ height: '45vh' }}>
        <MapComponent sensors={sensors} isActive={isActive} center={selectedSensor.position} />
        <div className="absolute top-4 right-4 z-[1000] w-[calc(100%-2rem)] max-w-sm">
          <Card className="shadow-lg border-0 bg-card/90 backdrop-blur-sm">
            <CardContent className="p-3 space-y-3">
               <Select value={selectedSensor.id} onValueChange={handleSensorChange}>
                <SelectTrigger className="w-full font-semibold">
                  <SelectValue placeholder="Seleccionar estación" />
                </SelectTrigger>
                <SelectContent>
                  {sensors.map((s) => (
                    <SelectItem key={s.id} value={s.id}>
                      {s.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
              
              {loadingWeather ? (
                <div className="grid grid-cols-2 gap-x-4 gap-y-2 text-sm font-medium">
                  <div className="flex items-center gap-1.5"><Thermometer className="h-5 w-5 text-primary" /><Skeleton className="h-5 w-12" /></div>
                  <div className="flex items-center gap-1.5"><CloudRain className="h-5 w-5 text-primary" /><Skeleton className="h-5 w-12" /></div>
                  <div className="flex items-center gap-1.5"><Droplet className="h-5 w-5 text-primary" /><Skeleton className="h-5 w-12" /></div>
                  <div className="flex items-center gap-1.5"><Wind className="h-5 w-5 text-primary" /><Skeleton className="h-5 w-12" /></div>
                </div>
              ) : weather ? (
                <div className="grid grid-cols-2 gap-x-4 gap-y-2 text-sm font-medium">
                  <div className="flex items-center gap-1.5">
                    <Thermometer className="h-5 w-5 text-primary" />
                    <span>{weather.temperature.toFixed(1)}°C</span>
                  </div>
                  <div className="flex items-center gap-1.5">
                    <CloudRain className="h-5 w-5 text-primary" />
                    <span>{weather.precipitation.toFixed(1)} mm</span>
                  </div>
                  <div className="flex items-center gap-1.5">
                    <Droplet className="h-5 w-5 text-primary" />
                    <span>{weather.humidity.toFixed(0)}%</span>
                  </div>
                  <div className="flex items-center gap-1.5">
                    <Wind className="h-5 w-5 text-primary" />
                    <span>{weather.wind.toFixed(1)} km/h</span>
                  </div>
                </div>
              ) : (
                <span className="text-sm text-destructive text-center block">Error al cargar clima</span>
              )}

              <Button onClick={handleSaveWeather} disabled={isSaving || loadingWeather} className="w-full">
                {isSaving ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <Save className="mr-2 h-4 w-4" />}
                {isSaving ? 'Guardando...' : 'Guardar Datos del Día'}
              </Button>
            </CardContent>
          </Card>
        </div>
        <div className="absolute bottom-6 left-4 w-auto z-[1000]">
          <div className="flex flex-col gap-3">
            <Button
              size="lg"
              className="w-full rounded-full shadow-lg text-lg py-6 bg-primary hover:bg-primary/90"
              onClick={() => setActiveView('monitoring')}
            >
              <LineChart className="mr-2 h-5 w-5" /> Ver Niveles en Vivo
            </Button>
            <Card className="shadow-lg border-0 bg-card/90 backdrop-blur-sm">
              <CardContent className="p-3 flex justify-between items-center">
                <span className="font-bold text-secondary-foreground text-sm">Estado General:</span>
                <Badge className="bg-green-500 text-white hover:bg-green-500 rounded-full text-sm">Normal</Badge>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
      <div className="flex-grow overflow-y-auto p-4 bg-background">
        <WeatherHistory />
      </div>
    </div>
  );
}
