"use client";

import { useEffect, useRef } from 'react';
import type { Sensor, MeteoStation } from '@/lib/types';

interface MapComponentProps {
  sensors: (Sensor | MeteoStation)[];
  isActive: boolean;
  center?: [number, number];
  zoom?: number;
}

// Since we are loading Leaflet via a script tag, we need to declare the 'L' global object.
declare const L: any;

const getIcon = (status: string) => {
    const colors: Record<string, string> = {
        Normal: '#28a745',
        Alerta: '#ffc107',
        Crítica: '#dc3545',
        Estación: '#0ea5e9' // info-500
    };
    const color = colors[status] || colors['Normal'];
    return L.divIcon({
        className: 'custom-div-icon',
        html: `<div style='background-color:${color};width:15px;height:15px;border-radius:50%;border:2px solid white;box-shadow:0 0 10px ${color};'></div>`,
        iconSize: [15, 15],
        iconAnchor: [7, 7]
    });
}


export default function MapComponent({ sensors, isActive, center, zoom }: MapComponentProps) {
  const mapRef = useRef<HTMLDivElement>(null);
  const mapInstance = useRef<any>(null);
  const markersRef = useRef<any[]>([]);

  useEffect(() => {
    // Ensure Leaflet is loaded and we're on the client
    if (typeof window !== 'undefined' && L && mapRef.current && !mapInstance.current) {
      const mapCenter: [number, number] = center || [-12.0681, -75.2100];
      const mapZoom = zoom || 13;
      
      mapInstance.current = L.map(mapRef.current, { zoomControl: false }).setView(mapCenter, mapZoom);
      
      L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
        attribution: '&copy; OpenStreetMap contributors'
      }).addTo(mapInstance.current);
      
      sensors.forEach(sensor => {
        const marker = L.marker(sensor.position, { icon: getIcon(sensor.status) })
          .addTo(mapInstance.current)
          .bindPopup(sensor.popup);
        markersRef.current.push(marker);
      });
    }

    return () => {
      // Clean up map instance on component unmount
      if (mapInstance.current) {
        // mapInstance.current.remove();
        // mapInstance.current = null;
      }
    };
  }, [sensors, center, zoom]);

  useEffect(() => {
    // Leaflet maps need to be explicitly told to resize when their container size changes.
    if (isActive && mapInstance.current) {
      setTimeout(() => {
        mapInstance.current.invalidateSize();
      }, 100);
    }
  }, [isActive]);

  return <div id="map" ref={mapRef} className="h-full w-full" />;
}
