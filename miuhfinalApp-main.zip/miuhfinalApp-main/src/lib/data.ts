import { AreaChart, CloudRain, Home, PlusCircle, Globe, TriangleAlert } from "lucide-react";
import type { NavItem, RecentEvent, Sensor, WaterLevelData, MeteoStation } from "./types";

export const waterLevelData: WaterLevelData[] = [
    { time: '10:00', level: 80 },
    { time: '10:15', level: 85 },
    { time: '10:30', level: 90 },
    { time: '10:45', level: 115 },
    { time: '11:00', level: 120 },
    { time: '11:15', level: 118 },
];

export const recentEvents: RecentEvent[] = [
    {
        Icon: CloudRain,
        title: "Lluvia Intensa",
        location: "Zona Chilca - 10:45 AM",
        iconColor: "text-primary"
    },
    {
        Icon: TriangleAlert,
        title: "Desagüe Obstruido",
        location: "El Tambo - 09:15 AM",
        iconColor: "text-yellow-500"
    }
];

export const sensors: Sensor[] = [
    {
        id: 'chilca',
        name: 'Zona Chilca',
        position: [-12.0800, -75.2200],
        status: 'Alerta',
        popup: "<b>Zona Chilca</b><br>Nivel: Alerta Moderada"
    },
    {
        id: 'tambo',
        name: 'El Tambo',
        position: [-12.0500, -75.2000],
        status: 'Normal',
        popup: "<b>El Tambo</b><br>Nivel: Normal"
    },
    {
        id: 'huancayo',
        name: 'Huancayo Centro',
        position: [-12.06513, -75.20486],
        status: 'Normal',
        popup: "<b>Huancayo Centro</b><br>Nivel: Normal"
    },
    {
        id: 'pilcomayo',
        name: 'Pilcomayo',
        position: [-12.035, -75.243],
        status: 'Normal',
        popup: "<b>Pilcomayo</b><br>Nivel: Normal"
    },
    {
        id: 'sapallanga',
        name: 'Sapallanga',
        position: [-12.163, -75.176],
        status: 'Normal',
        popup: "<b>Sapallanga</b><br>Nivel: Normal"
    },
    {
        id: 'huancan',
        name: 'Huancán',
        position: [-12.115, -75.216],
        status: 'Normal',
        popup: "<b>Huancán</b><br>Nivel: Normal"
    },
    {
        id: 'san-agustin',
        name: 'San Agustín de Cajas',
        position: [-11.983, -75.25],
        status: 'Normal',
        popup: "<b>San Agustín de Cajas</b><br>Nivel: Normal"
    }
];

export const meteoStations: MeteoStation[] = [
    { id: 'huancayo', name: 'Estación Huancayo', position: [-12.06513, -75.20486], status: 'Estación', popup: '<b>Estación Meteorológica Huancayo</b>' },
    { id: 'jauja', name: 'Estación Jauja', position: [-11.7750, -75.4950], status: 'Estación', popup: '<b>Estación Meteorológica Jauja</b>' },
    { id: 'tarma', name: 'Estación Tarma', position: [-11.4190, -75.6900], status: 'Estación', popup: '<b>Estación Meteorológica Tarma</b>' },
    { id: 'la-oroya', name: 'Estación La Oroya', position: [-11.5200, -75.9000], status: 'Estación', popup: '<b>Estación Meteorológica La Oroya</b>' },
    { id: 'chanchamayo', name: 'Estación Chanchamayo', position: [-11.0500, -75.3300], status: 'Estación', popup: '<b>Estación Meteorológica Chanchamayo</b>' },
];


export const navItems: NavItem[] = [
    { id: "home", label: "Inicio", Icon: Home },
    { id: "monitoring", label: "Monitoreo", Icon: AreaChart },
    { id: "report", label: "Reportar", Icon: PlusCircle },
    { id: "stations", label: "Estaciones", Icon: Globe },
];

export const incidentTypes = [
    'Inundación de Calle',
    'Desagüe Colapsado',
    'Vivienda Afectada',
    'Otro'
];
