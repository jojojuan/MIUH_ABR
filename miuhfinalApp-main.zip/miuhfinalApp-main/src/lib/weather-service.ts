
'use client';

import { z } from 'zod';

const weatherDataSchema = z.object({
  temperature: z.number(),
  humidity: z.number(),
  precipitation: z.number(),
  wind: z.number(),
  locationName: z.string(),
});

type WeatherData = z.infer<typeof weatherDataSchema>;

// Esta función ahora llama a tu backend para guardar los datos.
export async function saveWeatherData(weatherData: WeatherData) {
  const validatedData = weatherDataSchema.parse(weatherData);
  const token = localStorage.getItem('authToken');

  if (!token) {
    throw new Error('No estás autenticado.');
  }

  const backendUrl = process.env.NEXT_PUBLIC_BACKEND_URL || 'http://localhost:3001';
  const response = await fetch(`${backendUrl}/api/weather-reports`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      // ¡Muy importante! Enviamos el token para la autenticación en el backend.
      'Authorization': `Bearer ${token}`,
    },
    body: JSON.stringify(validatedData),
  });

  const responseData = await response.json();

  if (!response.ok) {
    throw new Error(responseData.message || 'Error al guardar los datos del clima.');
  }

  return responseData;
}
