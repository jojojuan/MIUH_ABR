
"use server";

import { z } from "zod";

const reportSchema = z.object({
  location: z.string(),
  incidentType: z.string(),
  description: z.string().optional(),
  // La evidencia (imagen) se manejará por separado si se sube a un servidor
});

export async function submitReport(formData: FormData) {
  const rawFormData = {
    location: formData.get('location'),
    incidentType: formData.get('incidentType'),
    description: formData.get('description'),
    // El archivo de evidencia se extrae por separado
    evidenceFile: formData.get('evidence'),
  };

  try {
    // Validamos solo los datos de texto
    const validatedData = reportSchema.parse({
        location: rawFormData.location,
        incidentType: rawFormData.incidentType,
        description: rawFormData.description,
    });
    
    // Aquí, en un futuro, podrías manejar la subida del archivo `evidenceFile`
    // a un servicio de almacenamiento como Amazon S3, Google Cloud Storage, etc.
    // y obtener una URL. Por ahora, lo omitimos.

    const token = localStorage.getItem('authToken');
    if (!token) {
        return { success: false, message: 'Autenticación requerida para enviar reporte.' };
    }
    
    const backendUrl = process.env.NEXT_PUBLIC_BACKEND_URL || 'http://localhost:3001';
    const response = await fetch(`${backendUrl}/api/incident-reports`, {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${token}`
        },
        body: JSON.stringify({
            ...validatedData,
            photoUrl: null // De momento no manejamos la subida de archivos
        }),
    });

    const responseData = await response.json();

    if (!response.ok) {
        throw new Error(responseData.message || "Error al enviar el reporte.");
    }
    
    return { success: true, message: "Reporte enviado con éxito." };

  } catch (error: any) {
    console.error("Report submission failed:", error);
    // Si es un error de validación de Zod
    if (error instanceof z.ZodError) {
        return { success: false, message: "Datos del formulario inválidos." };
    }
    return { success: false, message: error.message || "Error al enviar el reporte." };
  }
}

export async function getRealWeather(latitude: number, longitude: number) {
  try {
    const response = await fetch(`https://api.open-meteo.com/v1/forecast?latitude=${latitude}&longitude=${longitude}&current=temperature_2m,relative_humidity_2m,precipitation,wind_speed_10m`);
    if (!response.ok) {
      throw new Error('Network response was not ok');
    }
    const data = await response.json();
    
    return {
      success: true,
      data: {
        temperature: data.current.temperature_2m,
        humidity: data.current.relative_humidity_2m,
        precipitation: data.current.precipitation,
        wind: data.current.wind_speed_10m,
      },
    };
  } catch (error) {
    console.error("Failed to get real weather:", error);
    return { success: false, message: "Error al obtener el clima." };
  }
}
