import type { LucideIcon } from "lucide-react";

export type View = "home" | "monitoring" | "report" | "stations";

export type NavItem = {
    id: View;
    label: string;
    Icon: LucideIcon;
};

export type SensorStatus = "Normal" | "Alerta" | "Crítica";

export type StationStatus = "Estación";

export type Sensor = {
    id: string;
    name: string;
    position: [number, number];
    status: SensorStatus;
    popup: string;
};

export type MeteoStation = {
    id: string;
    name: string;
    position: [number, number];
    status: StationStatus;
    popup: string;
};


export type WaterLevelData = {
    time: string;
    level: number;
};

export type RecentEvent = {
    Icon: LucideIcon;
    title: string;
    location: string;
    iconColor: string;
};

export type Province = {
  name: string;
  lat: number;
  lon: number;
};
