
"use client";

import { useState, useEffect } from "react";
import type { View } from "@/lib/types";
import AppHeader from "@/components/app-header";
import BottomNav from "@/components/bottom-nav";
import HomeView from "@/components/views/home-view";
import MonitoringView from "@/components/views/monitoring-view";
import ReportView from "@/components/views/report-view";
import StationsView from "@/components/views/stations-view";
import AuthForm from "@/components/auth-form";
import { Loader2 } from "lucide-react";
import WelcomeScreen from "@/components/welcome-screen";

export default function Home() {
  const [activeView, setActiveView] = useState<View>("home");
  const [showWelcome, setShowWelcome] = useState(true);
  
  // Nuevo estado para manejar la autenticación, reemplazando a `useUser`
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [isAuthLoading, setIsAuthLoading] = useState(true);

  // Al cargar la app, revisamos si hay un token en localStorage
  useEffect(() => {
    const token = localStorage.getItem('authToken');
    if (token) {
      setIsAuthenticated(true);
    }
    setIsAuthLoading(false);
  }, []);


  const handleLoginSuccess = () => {
    setIsAuthenticated(true);
  };
  
  const handleLogout = () => {
    localStorage.removeItem('authToken');
    setIsAuthenticated(false);
  };


  const renderView = () => {
    switch (activeView) {
      case "home":
        return <HomeView setActiveView={setActiveView} isActive={activeView === 'home'} />;
      case "monitoring":
        return <MonitoringView />;
      case "report":
        return <ReportView setActiveView={setActiveView} />;
      case "stations":
        return <StationsView isActive={activeView === 'stations'} />;
      default:
        return <HomeView setActiveView={setActiveView} isActive={activeView === 'home'} />;
    }
  };

  if (isAuthLoading) {
    return (
      <div className="flex flex-col h-screen bg-background items-center justify-center">
        <Loader2 className="h-12 w-12 animate-spin text-primary" />
        <p className="mt-4 text-muted-foreground">Cargando...</p>
      </div>
    );
  }

  if (!isAuthenticated) {
    if (showWelcome) {
      return <WelcomeScreen onNext={() => setShowWelcome(false)} />;
    }
    return <AuthForm onLoginSuccess={handleLoginSuccess} />;
  }

  return (
    <div className="flex flex-col h-screen bg-background">
      <AppHeader onLogout={handleLogout} />
      <main className="flex-1 overflow-y-auto bg-gray-50">
        {renderView()}
      </main>
      <BottomNav activeView={activeView} setActiveView={setActiveView} />
    </div>
  );
}
