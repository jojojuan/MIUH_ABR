export const firebaseConfig = {
  "projectId": "studio-5516998518-2d69f",
  "appId": "1:973927838638:web:140235cdab436e77f30e3f",
  "apiKey": "AIzaSyCWuOmWAphTYuT9DUjOsamzBj0VbwUu6l4",
  "authDomain": "studio-5516998518-2d69f.firebaseapp.com",
  "measurementId": "",
  "messagingSenderId": "973927838638"
};
