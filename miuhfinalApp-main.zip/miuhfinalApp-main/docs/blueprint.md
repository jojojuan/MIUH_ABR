# **App Name**: Chilca Alerta

## Core Features:

- Real-time Water Level Monitoring: Displays real-time water levels from monitoring stations along the Chilca River, sourced from sensors. This functionality is read-only, designed to consume external data and visualize it for the user.
- Interactive Map: Show the up-to-date readings overlaid on a map with alert zones, plus other relevant infrastucture, rendered using Leaflet.
- User Reporting System: Enable users to submit incident reports with location data, incident type, and photographic evidence.
- Automated Alert Notifications: Generates alerts based on defined thresholds, to notify users of critical water levels and potential flood risks. Includes the use of a tool to predict whether an alert will be relevant based on current user location and other sensor inputs.

## Style Guidelines:

- Primary color: Deep sky blue (#00BFFF) for representing water and clear skies.
- Background color: Light gray (#E0E0E0) for a clean and neutral backdrop.
- Accent color: Orange (#FFA500) for alerts and calls to action to draw attention.
- Headline font: 'Poppins', a sans-serif font, for a contemporary and readable style. This is good for titles, alerts, and navigational elements. The same font should be used for body text, due to the small amounts of text found throughout the application.
- Use FontAwesome icons for visual clarity, and intuitive understanding of the app's function and data presentation.
- Prioritize a mobile-first, responsive layout with clearly defined sections for map, monitoring data, and reporting functionalities.
- Incorporate smooth transitions and subtle animations to enhance user experience (e.g., loading indicators, map updates, alert notifications).