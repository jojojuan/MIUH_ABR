# MIUH - Plataforma de Monitoreo y Alerta de Inundaciones

Proyecto acad�mico desarrollado en la Universidad Continental.

##  Descripci�n
MIUH es una plataforma web que permite monitorear en tiempo real los niveles de agua en zonas cr�ticas de Huancayo (Chilca y El Tambo), y emitir alertas a la comunidad.

##  Tecnolog�as utilizadas
- Frontend: Angular
- Backend: Node.js + Express
- Base de datos: MySQL
- Control de versiones: Git y GitHub

##  Estructura del proyecto
